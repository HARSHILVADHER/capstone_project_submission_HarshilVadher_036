package com.example.acadexa_app_one

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
